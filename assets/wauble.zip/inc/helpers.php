<?php

function console_log($data) {
  echo '<script>';
  echo 'console.log(' . json_encode($data) . ')';
  echo '</script>';
}

// Modified get_template_part() that accepts arguments
function wauble_get_template_part($file, $template_args = array(), $cache_args = array()) {
  $template_args = wp_parse_args($template_args);
  $cache_args = wp_parse_args($cache_args);
  if ($cache_args) {
    foreach ($template_args as $key => $value) {
      if (is_scalar($value) || is_array($value)) {
        $cache_args[$key] = $value;
      } elseif (is_object($value) && method_exists($value, 'get_id')) {
        $cache_args[$key] = call_user_method('get_id', $value);
      }
    }
    if (($cache = wp_cache_get($file, serialize($cache_args))) !== false) {
      if (!empty($template_args['return'])) {
        return $cache;
      }
      echo $cache;
      return;
    }
  }
  $file_handle = $file;
  do_action('start_operation', 'hm_template_part::' . $file_handle);
  if (file_exists(get_stylesheet_directory() . '/' . $file . '.php')) {
    $file = get_stylesheet_directory() . '/' . $file . '.php';
  } elseif (file_exists(get_template_directory() . '/' . $file . '.php')) {
    $file = get_template_directory() . '/' . $file . '.php';
  }
  ob_start();
  $return = require $file;
  $data = ob_get_clean();
  do_action('end_operation', 'hm_template_part::' . $file_handle);
  if ($cache_args) {
    wp_cache_set($file, $data, serialize($cache_args), 3600);
  }
  if (!empty($template_args['return'])) {
    if ($return === false) {
      return false;
    } else {
      return $data;
    }
  }
  echo $data;
}

function get_directions($address) {
  return sprintf('https://www.google.com/maps/dir/?api=1&destination=%s', $address);
}

// Adds a toast in the bottom right corner displaying current template while logged into admin


