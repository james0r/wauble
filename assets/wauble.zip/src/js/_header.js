let someFunc = name => name;

console.log( someFunc('jake') );